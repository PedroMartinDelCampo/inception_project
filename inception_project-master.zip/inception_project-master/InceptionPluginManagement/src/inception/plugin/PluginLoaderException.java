/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inception.plugin;

/**
 *
 * @author Pedro
 */
public class PluginLoaderException extends Exception {

    public PluginLoaderException(String msg, Throwable t) {
        super(msg, t);
    }    
    
}
